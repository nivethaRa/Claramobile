<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */

require APPPATH . 'libraries/REST_Controller.php';

/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class Admin extends REST_Controller {

    function __construct()
    {
         parent::__construct();

         $this->load->model('Admin_m');
         $this->load->model('Technician_m');

         $this->load->database();
    }

    public function login_post()
    {
        $username = $this->input->post('username');
        $password = $this->input->post('password');

   

        $user=$this->data['admindetail'] = $this->Admin_m->login($username,$password);


        if (!empty($user))
        {
            $this->set_response([ 'admin' => $user,
                'status' => TRUE,
                'message' => 'Admin detail is correct'
            ], REST_Controller::HTTP_OK); // OK (200) being the HTTP response code
        }
        else
        {
            $user= $this->Technician_m->login($username,$password);
                    if (!empty($user))
            {
                $this->set_response([ 'technician' => $user,
                    'status' => TRUE,
                    'message' => 'Technician detail is correct'
                ], REST_Controller::HTTP_OK); // OK (200) being the HTTP response code
            }
            else
            {    
                $this->set_response([
                    'status' => FALSE,
                    'message' => 'User could not be found'
                ], REST_Controller::HTTP_OK); // NOT_FOUND (404) being the HTTP response code
            }
        }
    }

   
}
