<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */

require APPPATH . 'libraries/REST_Controller.php';

/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class Test extends REST_Controller {

    function __construct()
    {
         parent::__construct();

         $this->load->model('Test_m');
         $this->load->database();
    }

    public function testdevice_post()
    {
        $data['device_id'] = $this->input->post('deviceid');
        $data['client_id'] = $this->input->post('clientid');
        $data['technician_id'] = md5($this->input->post('technicianid'));
        $data['all_tests']    = $this->input->post('alltests');
        $data['manual_tests'] = $this->input->post('manualtests');
        $data['test_names'] = $this->input->post('testnames');
        $data['suite_enabled'] = $this->input->post('suiteenabled');

        $test= $this->Test_m->testdevice($data);


        if ($test=='1')
        {
            $this->set_response([
                'status' => TRUE,
                'message' => 'test registered'
            ], REST_Controller::HTTP_OK); // OK (200) being the HTTP response code
        }
        else
        {
            $this->set_response([
                'status' => FALSE,
                'message' => 'test not registered.'
            ], REST_Controller::HTTP_OK); // NOT_FOUND (404) being the HTTP response code
        }
    }
   
   
}
