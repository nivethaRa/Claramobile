<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */

require APPPATH . 'libraries/REST_Controller.php';

/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class Site extends REST_Controller {

    function __construct()
    {
         parent::__construct();

         $this->load->model('Site_m');
         $this->load->database();
    }

    public function register_post()
    {
        $data['name'] = $this->input->post('name');
        $data['phone'] = $this->input->post('phone');
        $data['address'] = $this->input->post('address');
        $data['address_line_2']    = $this->input->post('address_line_2');
        $data['city'] = $this->input->post('city');
        $data['state'] = $this->input->post('state');
        $data['zipcode'] = $this->input->post('zipcode');
        $data['notes'] = $this->input->post('notes');
        $data['site_enabled'] = $this->input->post('site_enabled');

        $register= $this->Site_m->register($data);


        if ($register=='1')
        {
            $this->set_response([
                'status' => TRUE,
                'message' => 'Site registered'
            ], REST_Controller::HTTP_OK); // OK (200) being the HTTP response code
        }
        else
        {
            $this->set_response([
                'status' => FALSE,
                'message' => 'Site already exists.'
            ], REST_Controller::HTTP_OK); // NOT_FOUND (404) being the HTTP response code
        }
    }

    public function sites_get()
    {

        $register= $this->Site_m->site_list();


        if ($register)
        {
            $this->set_response(['Site' => $register,
                'status' => TRUE,
                'message' => 'Site list'
            ], REST_Controller::HTTP_OK); // OK (200) being the HTTP response code
        }
        else
        {
            $this->set_response([
                'status' => FALSE,
                'message' => 'Sites not exists.'
            ], REST_Controller::HTTP_OK); // NOT_FOUND (404) being the HTTP response code
        }
    }
    public function editsite_post()
    {
        $data['name'] = $this->input->post('name');
        $data['phone'] = $this->input->post('phone');
        $data['address'] = $this->input->post('address');
        $data['address_line_2']    = $this->input->post('address_line_2');
        $data['city'] = $this->input->post('city');
        $data['state'] = $this->input->post('state');
        $data['zipcode'] = $this->input->post('zipcode');
        $data['notes'] = $this->input->post('notes');
        $data['site_enabled'] = $this->input->post('site_enabled');
        $data['site_id'] = $this->input->post('siteid');

        $register= $this->Site_m->editsite($data);


        if ($register=='1')
        {
            $this->set_response([
                'status' => TRUE,
                'message' => 'Site updated'
            ], REST_Controller::HTTP_OK); // OK (200) being the HTTP response code
        }
  
    }
   
}
