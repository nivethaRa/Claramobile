<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */

require APPPATH . 'libraries/REST_Controller.php';

/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class Technician extends REST_Controller {

    function __construct()
    {
         parent::__construct();

         $this->load->model('Technician_m');
         $this->load->database();
    }

    public function register_post()
    {
        $data['username'] = $this->input->post('username');
        $data['fullname'] = $this->input->post('fullname');
        $data['password'] = md5($this->input->post('password'));
        $data['roles']    = $this->input->post('roles');
        $data['login_access'] = $this->input->post('loginaccess');

        $register= $this->Technician_m->register($data);


        if ($register=='1')
        {
            $this->set_response([
                'status' => TRUE,
                'message' => 'Technician registered'
            ], REST_Controller::HTTP_OK); // OK (200) being the HTTP response code
        }
        else
        {
            $this->set_response([
                'status' => FALSE,
                'message' => 'Username already exists.'
            ], REST_Controller::HTTP_OK); // NOT_FOUND (404) being the HTTP response code
        }
    }
    public function changepassword_post()
    {
        $data['password'] = md5($this->input->post('password'));
        $data['technician_id'] = $this->input->post('technician_id');

        $register= $this->Technician_m->changepassword($data);


        if ($register=='1')
        {
            $this->set_response([
                'status' => TRUE,
                'message' => 'Password changed'
            ], REST_Controller::HTTP_OK); // OK (200) being the HTTP response code
        }
        else
        {
            $this->set_response([
                'status' => FALSE,
                'message' => 'Technician not exists.'
            ], REST_Controller::HTTP_OK); // NOT_FOUND (404) being the HTTP response code
        }
    }
    public function technicians_get()
    {

        $register= $this->Technician_m->technician_list();


        if ($register)
        {
            $this->set_response(['Technician' => $register,
                'status' => TRUE,
                'message' => 'Technicians list'
            ], REST_Controller::HTTP_OK); // OK (200) being the HTTP response code
        }
        else
        {
            $this->set_response([
                'status' => FALSE,
                'message' => 'Technicians not exists.'
            ], REST_Controller::HTTP_OK); // NOT_FOUND (404) being the HTTP response code
        }
    }
    public function edittechnician_post()
    {
        $data['username'] = $this->input->post('username');
        $data['fullname'] = $this->input->post('fullname');
        $data['password'] = md5($this->input->post('password'));
        $data['roles']    = $this->input->post('roles');
        $data['login_access'] = $this->input->post('loginaccess');
        $data['technician_id'] = $this->input->post('technicianid');

        $register= $this->Technician_m->edittechnician($data);


        if ($register=='1')
        {
            $this->set_response([
                'status' => TRUE,
                'message' => 'Technician updated'
            ], REST_Controller::HTTP_OK); // OK (200) being the HTTP response code
        }
        else
        {
            $this->set_response([
                'status' => FALSE,
                'message' => 'Technician already exists.'
            ], REST_Controller::HTTP_OK); // NOT_FOUND (404) being the HTTP response code
        }
    }   
}
