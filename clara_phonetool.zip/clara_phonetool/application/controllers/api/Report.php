<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */

require APPPATH . 'libraries/REST_Controller.php';

/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class Report extends REST_Controller {

    function __construct()
    {
         parent::__construct();

         $this->load->model('Report_m');
         $this->load->database();
    }

    public function reports_post()
    {
        $technician_id = $this->input->post('technician_id');

        $reports= $this->Report_m->report_list($technician_id);


        if ($reports)
        {
            $this->set_response(['Reports' => $reports,
                'status' => TRUE,
                'message' => 'Reports list'
            ], REST_Controller::HTTP_OK); 
        }
        else
        {
            $this->set_response([
                'status' => FALSE,
                'message' => 'Reports not available.'
            ], REST_Controller::HTTP_OK); 
        }
    }
   
}
