<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */

require APPPATH . 'libraries/REST_Controller.php';

/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class Client extends REST_Controller {

    function __construct()
    {
         parent::__construct();

         $this->load->model('Client_m');
         $this->load->database();
    }

    public function register_post()
    {
        $data['name'] = $this->input->post('name');
        $data['phone'] = $this->input->post('phone');
        $data['address'] = $this->input->post('address');
        $data['address_line_2']    = $this->input->post('address_line_2');
        $data['city'] = $this->input->post('city');
        $data['state'] = $this->input->post('state');
        $data['zipcode'] = $this->input->post('zipcode');
        $data['notes'] = $this->input->post('notes');
        $data['client_enabled'] = $this->input->post('client_enabled');

        $register= $this->Client_m->register($data);


        if ($register=='1')
        {
            $this->set_response([
                'status' => TRUE,
                'message' => 'Client registered'
            ], REST_Controller::HTTP_OK); // OK (200) being the HTTP response code
        }
        else
        {
            $this->set_response([
                'status' => FALSE,
                'message' => 'Client already exists.'
            ], REST_Controller::HTTP_OK); // NOT_FOUND (404) being the HTTP response code
        }
    }
    public function editclient_post()
    {
        $data['name'] = $this->input->post('name');
        $data['phone'] = $this->input->post('phone');
        $data['address'] = $this->input->post('address');
        $data['address_line_2']    = $this->input->post('address_line_2');
        $data['city'] = $this->input->post('city');
        $data['state'] = $this->input->post('state');
        $data['zipcode'] = $this->input->post('zipcode');
        $data['notes'] = $this->input->post('notes');
        $data['client_enabled'] = $this->input->post('client_enabled');
        $data['client_id'] = $this->input->post('clientid');

        $register= $this->Client_m->editclient($data);


        if ($register=='1')
        {
            $this->set_response([
                'status' => TRUE,
                'message' => 'Client updated'
            ], REST_Controller::HTTP_OK); // OK (200) being the HTTP response code
        }
        else
        {
            $this->set_response([
                'status' => FALSE,
                'message' => 'Client already exists.'
            ], REST_Controller::HTTP_OK); // NOT_FOUND (404) being the HTTP response code
        }
    }
    public function clients_get()
    {

        $register= $this->Client_m->client_list();


        if ($register)
        {
            $this->set_response(['Client' => $register,
                'status' => TRUE,
                'message' => 'Client list'
            ], REST_Controller::HTTP_OK); // OK (200) being the HTTP response code
        }
        else
        {
            $this->set_response([
                'status' => FALSE,
                'message' => 'Clients not exists.'
            ], REST_Controller::HTTP_OK); // NOT_FOUND (404) being the HTTP response code
        }
    }
   
}
