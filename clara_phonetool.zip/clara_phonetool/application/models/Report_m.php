<?php
/**
 * @author tshirtecommerce - www.tshirtecommerce.com
 * @date: 2015-01-10
 * 
 * @copyright  Copyright (C) 2015 tshirtecommerce.com. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 *
 */
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Report_m extends CI_Model
{
	
	public $_table_name 	= 'test_reports';
	public $_primary_key 	= 'report_id';

	function __construct ()
	{
		parent::__construct();
	}

	public function report_list($technician_id)
	{

		 $this->db->select('test_reports.*','client_details.name');
		 $this->db->from('test_reports');
		 $this->db->where('report_technician_id',$technician_id);
		 $this->db->join('client_details', 'client_details.client_id = test_reports.report_client_id','left');
	     $query = $this->db->get();
         $row=$query->result();
         return $row;

	}

}