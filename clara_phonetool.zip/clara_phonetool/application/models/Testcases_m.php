<?php
/**
 * @author tshirtecommerce - www.tshirtecommerce.com
 * @date: 2015-01-10
 * 
 * @copyright  Copyright (C) 2015 tshirtecommerce.com. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 *
 */
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Testcases_m extends CI_Model
{
	
	public $_table_name 	= 'test_cases';
	public $_primary_key 	= 'test_case_id';

	function __construct ()
	{
		parent::__construct();
	}

	public function testcases()
	{
         $this->db->select('*'); 
         $this->db->from('test_cases');
         $query = $this->db->get();
         $row=array();
         $row = $query->result();
         return $row;
	}

}