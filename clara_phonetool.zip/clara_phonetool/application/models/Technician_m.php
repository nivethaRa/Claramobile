<?php
/**
 * @author tshirtecommerce - www.tshirtecommerce.com
 * @date: 2015-01-10
 * 
 * @copyright  Copyright (C) 2015 tshirtecommerce.com. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 *
 */
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Technician_m extends CI_Model
{
	
	public $_table_name 	= 'technician_details';
	public $_primary_key 	= 'technician_id';

	function __construct ()
	{
		parent::__construct();
	}

	public function register($data)
	{

	     $this->db->select('*'); 
	     $this->db->from('technician_details');
	     $this->db->where('username', $data['username']);
	     $query = $this->db->get();
	     if ($query->num_rows() == 0) {
	       $insert=$this->db->insert('technician_details',$data);
	       return $insert;
	     } else {
	         return false;
	     }

	}
	public function changepassword($data)
	{
		 $data1 = array(
			'password' => $data['password']
		 );
	     $this->db->where('technician_id', $data['technician_id']);
	     $updatepassword=$this->db->update('technician_details',$data1);
	     return $updatepassword;
	     // $this->db->last_query(); die;
	     // exit;

	}	
		public function technician_list()
	{
	
	     $this->db->select('*'); 
	     $this->db->from('technician_details');
	     $query = $this->db->get();
	     $row=array();
	     $row = $query->result();
	     return $row;
	}	
	public function login($username,$password)
	{
		$this->db->where('username', $username);
		$this->db->where('password', md5($password));
		$query = $this->db->get('technician_details');
		return $query->result();
	}	
	public function edittechnician($data)
    {

           $this->db->where('technician_id', $data['technician_id']);
           $update=$this->db->update('technician_details',$data);
           return $update;

    }
}