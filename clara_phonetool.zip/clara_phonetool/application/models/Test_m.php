<?php
/**
 * @author tshirtecommerce - www.tshirtecommerce.com
 * @date: 2015-01-10
 * 
 * @copyright  Copyright (C) 2015 tshirtecommerce.com. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 *
 */
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Test_m extends CI_Model
{
	
	public $_table_name 	= 'test_devices';
	public $_primary_key 	= 'test_device_id';

	function __construct ()
	{
		parent::__construct();
	}

	public function testdevice($data)
	{

	       $insert=$this->db->insert('test_devices',$data);
           return $insert;
	}


}