<?php
/**
 * @author tshirtecommerce - www.tshirtecommerce.com
 * @date: 2015-01-10
 * 
 * @copyright  Copyright (C) 2015 tshirtecommerce.com. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 *
 */
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Client_m extends CI_Model
{
    
    public $_table_name     = 'client_details';
    public $_primary_key    = 'client_id';

    function __construct ()
    {
        parent::__construct();
    }

    public function register($data)
    {

         $this->db->select('*'); 
         $this->db->from('client_details');
         $this->db->where('name', $data['name']);
         $query = $this->db->get();
         if ($query->num_rows() == 0) {
           $insert=$this->db->insert('client_details',$data);
           return $insert;
         } else {
             return false;
         }

    }
    public function editclient($data)
    {

           $this->db->where('client_id', $data['client_id']);
           $update=$this->db->update('client_details',$data);
           return $update;

    }
     
    public function client_list()
    {
    
         $this->db->select('*'); 
         $this->db->from('client_details');
         $query = $this->db->get();
         $row=array();
         $row = $query->result();
         return $row;
    }   
}